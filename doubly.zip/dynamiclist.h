#include <stdbool.h>

#ifndef DYNAMICLIST_H
#define DYNAMICLIST_H

typedef struct{
    int* elems;
    int count;
    int max;
} ListD;

void initList(ListD* list, int max);
void insertFrontD(ListD* list, int val);
void displayD(ListD list);
bool increaseSpace(ListD* list, int increase);
void insertRearD(ListD* list, int val);
void insertIntoD(ListD* list, int val, int index);

void deleteFrontD(ListD* list);
void deleteRearD(ListD* list);
void deleteItemD(ListD* list, int item);
void deleteAllOccurenceD(ListD *list, int item);

#endif 