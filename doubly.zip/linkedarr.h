#ifndef LINKEDARR_H
#define LINKEDARR_H

typedef struct node{
    int item;
    struct node* next;
} Linked, *LinkedPtr;


void insertFrontL(LinkedPtr* list, int val);
void insertRearL(LinkedPtr* list, int val);
void insertIntoL(LinkedPtr* list, int val, int index);
void deleteFrontL(LinkedPtr* list);
void deleteRearL(LinkedPtr* list);
void deleteItemL(LinkedPtr* list, int item);
void displayL(LinkedPtr list);
void deleteAllOccurenceL(LinkedPtr *list, int item);

#endif 