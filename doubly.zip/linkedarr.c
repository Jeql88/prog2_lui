#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "linkedarr.h"

void deleteAllOccurenceL(LinkedPtr *list, int item){
    LinkedPtr* trav;
    LinkedPtr temp;
    if (*list != NULL){
        for (trav = list; (*trav) != NULL;){
            if ((*trav)->item == item){
                temp = *trav;
                *trav = temp->next;
                free(temp);
            }
            else{
                trav = &(*trav)->next;
            }
        }
    }
}
void deleteItemL(LinkedPtr* list, int item){
    LinkedPtr* trav;
    LinkedPtr temp;
    if (*list != NULL){
        for (trav = list; (*trav) != NULL && (*trav)->item != item ; trav = &(*trav)->next){}
        temp = *trav;
        *trav = temp->next;
        free(temp);
    }
}
void deleteFrontL(LinkedPtr* list){
    LinkedPtr temp;
    if (*list != NULL){
        LinkedPtr temp = *list;
        *list = (*list)->next;
        free(temp);
    }
}
void deleteRearL(LinkedPtr* list){
    LinkedPtr* trav;
    LinkedPtr temp;
    if (*list != NULL){
        for (trav = list; (*trav)->next != NULL; trav = &(*trav)->next){}
        temp = *trav;
        *trav = NULL;
        free(temp);
    }
}
void insertIntoL(LinkedPtr* list, int val, int index){
    LinkedPtr* trav;
    LinkedPtr temp = malloc(sizeof(struct node));
    if (temp != NULL){
        int i;
        for (trav = list, i = 0; (*trav) != NULL && i < index; trav = &(*trav)->next, ++i){}
        temp->item = val;
        temp->next = *trav;
        *trav = temp;
    }
}
void insertFrontL(LinkedPtr* list, int val){
    LinkedPtr temp = malloc(sizeof(struct node));
    if (temp != NULL){
        temp->item = val;
        temp->next = *list;
        *list = temp;
    }
}
void insertRearL(LinkedPtr* list, int val){
    LinkedPtr* trav;
    LinkedPtr temp = malloc(sizeof(struct node));
    if (temp != NULL){
        for (trav = list; (*trav) != NULL; trav = &(*trav)->next){}
        temp->item = val;
        temp->next = NULL;
        *trav = temp;
    }
}
void displayL(LinkedPtr list){
    LinkedPtr trav;
    for (trav = list; trav!= NULL ; trav = trav->next){
        (trav->next != NULL)? printf("%d, ",trav->item): printf("%d",trav->item);
    }
    printf("\n");
}