#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "staticlist.h"


void insertFront(List* list, int val){
    int i;
    if (list->count < MAX){
        for (i = list->count; i > 0; --i){
            list->items[i] = list->items[i-1]; 
        }
        ++list->count;
        list->items[i] = val;
    }
}

void display(List list){
    int i;
    for (i = 0; i < list.count; ++i){
        printf("%d",list.items[i]);
        if (i < list.count -1){
            printf(", ");
        }
    }
    printf("\n");
}

void insertRear(List* list, int val){
    //guardstatement
    if (list->count < MAX){
        list->items[list->count++] = val;
    }
}

void insertInto(List* list, int val, int index){
    int i;
    if (list->count < MAX){
        for (i = list->count; i > 0 && i > index; --i){
            list->items[i] = list->items[i-1]; 
        }
        ++list->count;
        list->items[i] = val;
    }
}

void deleteFront(List *list){
    int i;
    if (list->count > 0){
        for (i = 1 ; i < list->count; ++i){
            list->items[i-1] = list->items[i]; 
        }
        list->count--;
    }
}
void deleteRear(List *list){
    if (list->count > 0){
        list->count--;
    }
}    
void deleteItem(List *list, int item){
    int i,k;
    if (list->count > 0){
        for (i = 0; i < list->count ;++i){
            if (list->items[i] == item){
                list->items[i] = list->items[i+1];
            }
            list->count--;
        }
    }
}
void deleteAllOccurence(List* list, int item){
    int i,k;
    if (list->count > 0){
        for (i = 0; i < list->count;){
            if (list->items[i] == item){
                memcpy(&list->items[i],&list->items[i+1],sizeof(list->items));
                list->count--;
            }else{
                i++;
            }
        }
    }
}