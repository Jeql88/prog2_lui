#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include "dynamiclist.h"


void displayD(ListD list){
    int i;
    for (i = 0; i < list.count; ++i){
        printf("%d",list.elems[i]);
        if (i < list.count -1){
            printf(", ");
        }
    }
    printf("\n");
}
void initList(ListD* list, int max){
    list->max = max;
    list->elems = malloc(sizeof(int)*max);
    list->count = 0;
}
bool increaseSpace(ListD* list, int increase){
    list->max += increase;
    list->elems = realloc(list->elems,sizeof(int)*(list->max));
    if (list->elems != NULL){
        return true;
    }else{
        return false;
    }
}
void insertRearD(ListD* list, int val){
    bool success = true;
    if (list->count >= list->max){
        success = increaseSpace(list,1);
    } 
    if (success == true){
        list->elems[list->count++] = val;
    }
}
void insertIntoD(ListD* list, int val, int index){
    bool success = true;
    if (list->count >= list->max){
        success = increaseSpace(list,1);
    } 
    if (success == true){
        int i;
        if (list->count < list->max){
            for (i = list->count; i > 0 && i > index; --i){
                list->elems[i] = list->elems[i-1]; 
            }
            ++list->count;
            list->elems[i] = val;
        }
    }
}
void insertFrontD(ListD* list, int val){
    bool success = true;
    if (list->count >= list->max){
        success = increaseSpace(list,1);
    } 
    if (success == true){
        int i;
        for (i = list->count; i > 0; --i){
            list->elems[i] = list->elems[i-1];
        }
        list->count++;
        list->elems[i] = val;
        
    }
}
void deleteFrontD(ListD *list){
    int i;
    if (list->count > 0){
        for (i = 1 ; i < list->count; ++i){
            list->elems[i-1] = list->elems[i]; 
        }
        list->count--;
    }
}
void deleteRearD(ListD *list){
    if (list->count > 0){
        list->count--;
    }
}    
void deleteItemD(ListD *list, int item){
    int i,k;
    if (list->count > 0){
        for (i = 0; i < list->count ;++i){
            if (list->elems[i] == item){
                list->elems[i] = list->elems[i+1];
            }
            list->count--;
        }
    }
}
void deleteAllOccurenceD(ListD* list, int item){
    int i,k;
    if (list->count > 0){
        for (i = 0; i < list->count;){
            if (list->elems[i] == item){
                memcpy(&list->elems[i],&list->elems[i+1],sizeof(list->elems));
                list->count--;
            }else{
                i++;
            }
        }
    }
}