#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "staticlist.h"
#include "dynamiclist.h"
#include <stdbool.h>
#include "linkedarr.h"

// typedef struct node{
//     int item;
//     struct node* next;
// } Linked, *LinkedPtr;
typedef struct node2{
    int item;
    struct node2* next;
    struct node2* prev;
} Node, *NodePtr;

typedef struct{
    NodePtr head;
    NodePtr tail;
} doubly;

void insertFront2(doubly* list, int val);
void insertRear2(doubly* list, int val);
void insertInto2(doubly* list, int val, int index);
void deleteFront2(doubly* list);
void deleteRear2(doubly* list);
void deleteItem2(doubly* list, int item);
void display2(doubly list);
void deleteAllOccurence2(doubly *list, int item);
void displayrev2(doubly list);

void main(){
    doubly list;
    
    list.head = NULL;
    list.tail = NULL;
    
    insertFront2(&list,2);
    insertFront2(&list,1);
    insertFront2(&list,3);
    display2(list);
    
    // insertRear2(&list,5);
    display2(list);
    displayrev2(list);
}

void display2(doubly list){
    NodePtr trav;
    for (trav = list.head; trav!= NULL ; trav = trav->next){
        (trav->next != NULL)? printf("%d, ",trav->item): printf("%d",trav->item);
    }
    printf("\n");
}
void displayrev2(doubly list){
    NodePtr trav;
    for (trav = list.tail; trav!= NULL ; trav = trav->prev){
        (trav->next != NULL)? printf("%d, ",trav->item): printf("%d",trav->item);
    }
    printf("\n");
}
void insertFront2(doubly* list, int val){
    NodePtr temp = malloc(sizeof(struct node));
    if (temp != NULL){
        if (list->head == NULL && list->tail == NULL){
            temp->item = val;
            temp->prev = list->head;
            temp->next = list->head;
            list->head = temp;
            list->tail = temp;
        } else{
            temp->item = val;
            temp->prev = list->head;
            temp->next = list->head;
            list->head = temp;
        }
    }
}
void insertRear2(doubly* list, int val){
    NodePtr temp = malloc(sizeof(struct node));
    if (temp != NULL){
        if (list->head == NULL && list->tail == NULL){
            temp->item = val;
            temp->next = list->head;
            list->head = temp;
            list->tail = temp;
        } else{
            temp->item = val;
            temp->next = NULL;
            list->tail->next = temp;
            list->tail = temp;
            
        }
    }
}