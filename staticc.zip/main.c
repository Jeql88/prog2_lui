#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "staticlist.h"



void main(){
    List test;
    test.count = 0;
    insertFront(&test,5);
    insertRear(&test,3);
    insertInto(&test,2,0);
    display(test);
    deleteFront(&test);
    display(test);
    deleteItem(&test,5);
    display(test);
    insertFront(&test,5);
    insertFront(&test,5);
    insertFront(&test,5);
    insertFront(&test,5);
    display(test);
    deleteAllOccurence(&test,5);
    display(test);
    // insertFront(&test,5);
    // display(test);
    // deleteItem(&test,5);
    // display(test);
}
