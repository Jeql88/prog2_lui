#ifndef STATICLIST_H
#define STATICLIST_H



typedef struct{
    int *list;
    int count;
    int max;
} dArrayList;
#endif 